#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<unistd.h>
#include<sys/mman.h>  //mmap
#include<fcntl.h>  //open
#include<string.h>

void getOSName(char* osname, char * mmap)
{	
	int i;
	for(i=0;i<8;i++)
		osname[i] = mmap[3+i];
	
	//fseek(fp,3L,SEEK_SET);
	//fread(osname,1,8,fp);
}

int getTotalSize(char * mmap)
{
	int *tmp1 = malloc(sizeof(int));
	int *tmp2 = malloc(sizeof(int));
	int retVal;
	//fseek(fp,19L,SEEK_SET);
	//fread(tmp1,1,1,fp);
	//fread(tmp2,1,1,fp);
	* tmp1 = mmap[19];
	* tmp2 = mmap[20];
	// Use a for loop if necessary
	retVal = *tmp1+((*tmp2)<<8);
	//retVal = (mmap[19] << 0) | (mmap[20] << 8);
	free(tmp1);
	free(tmp2);
	return retVal;
};


int main(int argc, char** argv)
{
	FILE *fp;

	int fd;
	struct stat sf;
	char *p;
	char *osname = malloc(sizeof(char)*8);
	int size;

	if ((fd=open(argv[1], O_RDONLY)))
	{
		fstat(fd, &sf);

		// void * mmap(void * addr, size_t length, int prot, 
		//		int flags, int fd, off_t offset);

		p = mmap(NULL,sf.st_size, PROT_READ, MAP_SHARED, fd, 0);

		printf("Successfully open the image file.\n");
		
		getOSName(osname, p);
		printf("OS Name: %s\n", osname);
		
		size = getTotalSize(p);
		printf("Total Sectors: %d\n", size);
		printf("Total Space: %d\n", size * 512);			
	}

	else
		printf("Fail to open the image file.\n");

	free(osname);
	close(fd);
	return 0;
}
